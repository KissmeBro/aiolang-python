
# aiolang/__init__.py
from .aiolang import Aiolang
from .exceptions import TranslationError


__all__ = ["TranslationError", "Aiolang"]
__version__ = "0.0.1"
