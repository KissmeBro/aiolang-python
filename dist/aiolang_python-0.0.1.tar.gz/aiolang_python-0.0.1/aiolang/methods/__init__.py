# aiolang/methods/__init__.py
from .translate_text import TranslateText
from .text_to_voice import TextToVoice

__all__ = ["TranslateText", "TextToVoice"]