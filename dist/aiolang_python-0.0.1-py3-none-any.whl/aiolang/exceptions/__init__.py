# aiolang/exceptions/__init__.py
from .exceptions import TranslationError


__all__ = ["TranslationError"]