# aiolang/network/__init__.py
from .network import Network


__all__ = ["Network"]